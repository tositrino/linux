//
//  EasyQuantisAppDelegate.h
//  EasyQuantis
//
//  Created by Administrateur on 04.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface EasyQuantisAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
