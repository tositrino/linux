
   .====================================.
===|   Quantis Software Package README  |======================================
   °====================================°

This folder and its sub-folders contains the Quantis Software:

* README.txt
    This file.

* Credits.txt
    Credits to people who have offered help, support and/or code.

* License.txt
    Software license.

* User_Manual.pdf
    The Quantis' user manual.

* Distribution/
    Files used to build packages.

* Drivers/
    Quantis drivers.

* Libs-Apps/
    Source code of the Quantis library and EasyQuantis application.

* Packages/
    Packages with binaries for various platforms.

* Samples/
    Code samples for various cases

