/* This is the jpeg hacked version of Mark W. McClelland's Original driver.
*
* This drivers is GPL so use it as you like, but this version is never to be 
* seriously developped. It is only provided for means of compatibility with current v4l.
* Moreover, it is NOT tested with ov511 or ov518 so don't expect it to work - 
* anyway for those cameras, you don't need it.
*
* Culprit for this module: Romain Beauxis <toots@rastageeks.org>
* See http://www.rastageeks.org/ov51x-jpeg/ for more details.
*/



/*
 * ov51x.h, part of ov51x driver
 *
 * Copyright (c) 1999-2003 Mark W. McClelland
 * Support for OV519, OV8610 Copyright (c) 2003 Joerg Heckenbach <joerg@heckenbach-aw.de>
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __LINUX_OV51X_H
#define __LINUX_OV51X_H

#include <asm/uaccess.h>
#include <linux/slab.h>
#include <linux/videodev.h>
#include <linux/smp_lock.h>
#include <linux/usb.h>

#define OV511_DEBUG	/* Turn on debug messages */

#ifdef OV511_DEBUG
	#define PDEBUG(level, fmt, args...) \
		if (debug >= (level)) info("[%s:%d] " fmt, \
		__FUNCTION__, __LINE__ , ## args)
#else
	#define PDEBUG(level, fmt, args...) do {} while(0)
#endif

/* This macro restricts an int variable to an inclusive range */
#define RESTRICT_TO_RANGE(v,mi,ma) { \
	if ((v) < (mi)) (v) = (mi); \
	else if ((v) > (ma)) (v) = (ma); \
}

#include <media/v4l2-common.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
#include <media/v4l2-ioctl.h>
#endif

/* --------------------------------- */
/* DEFINES FOR OV511 AND OTHER CHIPS */
/* --------------------------------- */

/* USB IDs */
#define VEND_OMNIVISION	0x05A9
#define PROD_OV511		0x0511
#define PROD_OV511PLUS	0xA511
#define PROD_OV518		0x0518
#define PROD_OV518PLUS	0xA518
#define PROD_OV530             0x0530
/* Hardwired OV519 Products IDs. The GPIO[3:0] pins appear to control the upper
 * nibble of the PID, so there are 16 of these. The behavior of the chip isn't
 * otherwise affected by these pins. They should all work as long as the sensor
 * is supported.
 */
#define PROD_OV519		0x0519
#define PROD_OV1519		0x1519
#define PROD_OV2519		0x2519
#define PROD_OV3519		0x3519
#define PROD_OV4519		0x4519
#define PROD_OV5519		0x5519
#define PROD_OV6519		0x6519
#define PROD_OV7519		0x7519
#define PROD_OV8519		0x8519
#define PROD_OV9519		0x9519
#define PROD_OVA519		0xA519
#define PROD_OVB519		0xB519
#define PROD_OVC519		0xC519
#define PROD_OVD519		0xD519
#define PROD_OVE519		0xE519
#define PROD_OVF519		0xF519

#define VEND_MATTEL		0x0813
#define PROD_ME2CAM		0x0002

#define VEND_SONY		0x054c
#define PROD_EYETOY4		0x0154
#define PROD_EYETOY5		0x0155
#define PROD_EYETOY6		0x0156
#define PROD_EYETOY7		0x0157

#define VEND_MICROSOFT         0x45e
#define PROD_XBOX_CAM          0x28c           /* OV530 */

#define VEND_CREATIVE         0x041e
#define PROD_LIVE_VISTA_IM    0x4052
#define PROD_LIVE_VISTA_VF0330     0x405f
#define PROD_LIVE_VISTA_VF0350     0x4060	/* Creative Live Cam */
#define PROD_LIVE_VISTA_VF0400     0x4061       /* Creative Live! Cam Notebook Pro */
#define PROD_LIVE_VISTA_VF0420     0x4064
#define PROD_LIVE_VISTA_VF0350_A   0x4067
#define PROD_LIVE_VISTA_VF0470     0x4068       /* Creative Live!  Cam Notebook */ 

/* --------------------------------- */
/*      DEVICE IMPLEMENTATIONS       */
/* --------------------------------- */

enum {
	IMP_GENERIC,
	IMP_EYETOY,
	IMP_LIVE,
};

/* --------------------------------- */
/*     OV51x REGISTER MNEMONICS      */
/* --------------------------------- */

/* Camera interface register numbers */
#define R511_CAM_DELAY		0x10
#define R511_CAM_EDGE		0x11
#define R511_CAM_PXCNT		0x12
#define R511_CAM_LNCNT		0x13
#define R511_CAM_PXDIV		0x14
#define R511_CAM_LNDIV		0x15
#define R511_CAM_UV_EN		0x16
#define R511_CAM_LINE_MODE	0x17
#define R511_CAM_OPTS		0x18

/* Snapshot mode camera interface register numbers */
#define R511_SNAP_FRAME		0x19
#define R511_SNAP_PXCNT		0x1A
#define R511_SNAP_LNCNT		0x1B
#define R511_SNAP_PXDIV		0x1C
#define R511_SNAP_LNDIV		0x1D
#define R511_SNAP_UV_EN		0x1E
#define R511_SNAP_OPTS		0x1F

/* DRAM register numbers */
#define R511_DRAM_FLOW_CTL	0x20
#define R511_DRAM_ARCP		0x21
#define R511_DRAM_MRC		0x22
#define R511_DRAM_RFC		0x23

/* ISO FIFO register numbers */
#define R51x_FIFO_PSIZE		0x30	/* 2 bytes wide w/ OV518(+) */
#define R511_FIFO_OPTS		0x31

/* Parallel IO register numbers */
#define R511_PIO_OPTS		0x38
#define R511_PIO_DATA		0x39
#define R511_PIO_BIST		0x3E
#define R518_GPIO_IN		0x55	/* OV518(+) only */
#define R518_GPIO_OUT		0x56	/* OV518(+) only */
#define R518_GPIO_CTL		0x57	/* OV518(+) only */
#define R518_GPIO_PULSE_IN	0x58	/* OV518(+) only */
#define R518_GPIO_PULSE_CLEAR	0x59	/* OV518(+) only */
#define R518_GPIO_PULSE_POL	0x5a	/* OV518(+) only */
#define R518_GPIO_PULSE_EN	0x5b	/* OV518(+) only */
#define R518_GPIO_RESET		0x5c	/* OV518(+) only */

/* I2C registers */
#define R511_I2C_CTL		0x40
#define R518_I2C_CTL		0x47	/* OV518(+) only */
#define R51x_I2C_W_SID		0x41
#define R51x_I2C_SADDR_3	0x42
#define R51x_I2C_SADDR_2	0x43
#define R51x_I2C_R_SID		0x44
#define R51x_I2C_DATA		0x45
#define R51x_I2C_CLOCK		0x46
#define R51x_I2C_TIMEOUT	0x47

/* I2C snapshot registers */
#define R511_SI2C_SADDR_3	0x48
#define R511_SI2C_DATA		0x49

/* System control registers */
#define R51x_SYS_RESET		0x50
		/* Reset type definitions */
#define	OV511_RESET_UDC		0x01
#define	OV511_RESET_I2C		0x02
#define	OV511_RESET_FIFO	0x04
#define	OV511_RESET_OMNICE	0x08
#define	OV511_RESET_DRAM	0x10
#define	OV511_RESET_CAM_INT	0x20
#define	OV511_RESET_OV511	0x40
#define	OV511_RESET_NOREGS	0x3F /* All but OV511 & regs */
#define	OV511_RESET_ALL		0x7F

#define R511_SYS_CLOCK_DIV	0x51
#define R51x_SYS_SNAP		0x52
#define R51x_SYS_INIT         	0x53
#define R511_SYS_PWR_CLK	0x54 /* OV511+/OV518(+) only */
#define R511_SYS_LED_CTL	0x55 /* OV511+ only */
#define R511_SYS_USER		0x5E
#define R511_SYS_CUST_ID	0x5F

/* OmniCE (compression) registers */
#define R511_COMP_PHY		0x70
#define R511_COMP_PHUV		0x71
#define R511_COMP_PVY		0x72
#define R511_COMP_PVUV		0x73
#define R511_COMP_QHY		0x74
#define R511_COMP_QHUV		0x75
#define R511_COMP_QVY		0x76
#define R511_COMP_QVUV		0x77
#define R511_COMP_EN		0x78
#define R511_COMP_LUT_EN	0x79
#define R511_COMP_LUT_BEGIN	0x80

// OV519 Camera interface register numbers
#define OV519_CAM_H_SIZE		0x10
#define OV519_CAM_V_SIZE		0x11
#define OV519_CAM_X_OFFSETL		0x12
#define OV519_CAM_X_OFFSETH		0x13
#define OV519_CAM_Y_OFFSETL		0x14
#define OV519_CAM_Y_OFFSETH		0x15
#define OV519_CAM_DIVIDER		0x16
#define OV519_CAM_DFR			0x20
#define OV519_CAM_SR			0x21
#define OV519_CAM_FRAR			0x22
#define OV519_CAM_FORMAT		0x25

// OV519 System Controller register numbers
#define OV519_SYS_RESET0		0x50
#define OV519_SYS_RESET1		0x51
#define OV519_SYS_EN_CLK0		0x53
#define OV519_SYS_EN_CLK1		0x54
#define OV519_SYS_AUDIO_CLK		0x55
#define OV519_SYS_SNAPSHOT		0x57
#define OV519_SYS_PONOFF		0x58
#define OV519_SYS_CAMERA_CLK	0x59
#define OV519_SYS_CTRL1			0x5A
#define OV519_SYS_DEB_CLK		0x5B
#define OV519_SYS_CLK			0x5C
#define OV519_SYS_PWDN			0x5D
#define OV519_SYS_USR_DFN		0x5E
#define OV519_SYS_CTRL2			0x5F
#define OV519_SYS_INTERRUPT0	0x60
#define OV519_SYS_INTERRUPT1	0x61
#define OV519_SYS_MASK0			0x62
#define OV519_SYS_MASK1			0x63
#define OV519_SYS_VCI_R0		0x64
#define OV519_SYS_VCI_R1		0x65
#define OV519_SYS_ADC_CTRL		0x68
#define OV519_SYS_UC_CTRL		0x6D

/* OV519 GPIO register numbers */
#define OV519_GPIO_DATA_OUT0		0x71
#define OV519_GPIO_IO_CTRL0		0x72

/* --------------------------------- */
/*         ALTERNATE NUMBERS         */
/* --------------------------------- */

/* Alternate numbers for various max packet sizes (OV511 only) */
#define OV511_ALT_SIZE_992	0
#define OV511_ALT_SIZE_993	1
#define OV511_ALT_SIZE_768	2
#define OV511_ALT_SIZE_769	3
#define OV511_ALT_SIZE_512	4
#define OV511_ALT_SIZE_513	5
#define OV511_ALT_SIZE_257	6
#define OV511_ALT_SIZE_0	7

/* Alternate numbers for various max packet sizes (OV511+ only) */
#define OV511PLUS_ALT_SIZE_0	0
#define OV511PLUS_ALT_SIZE_33	1
#define OV511PLUS_ALT_SIZE_129	2
#define OV511PLUS_ALT_SIZE_257	3
#define OV511PLUS_ALT_SIZE_385	4
#define OV511PLUS_ALT_SIZE_513	5
#define OV511PLUS_ALT_SIZE_769	6
#define OV511PLUS_ALT_SIZE_961	7

/* Alternate numbers for various max packet sizes (OV518(+) only) */
#define OV518_ALT_SIZE_0	0
#define OV518_ALT_SIZE_128	1
#define OV518_ALT_SIZE_256	2
#define OV518_ALT_SIZE_384	3
#define OV518_ALT_SIZE_512	4
#define OV518_ALT_SIZE_640	5
#define OV518_ALT_SIZE_768	6
#define OV518_ALT_SIZE_896	7

/* Alternate numbers for various max packet sizes (OV519 only) */
#define OV519_ALT_SIZE_0	0
#define OV519_ALT_SIZE_384	1
#define OV519_ALT_SIZE_512	2
#define OV519_ALT_SIZE_768	3
#define OV519_ALT_SIZE_896	4

/* --------------------------------- */
/*     OV7610 REGISTER MNEMONICS     */
/* --------------------------------- */

/* OV7610 registers */
#define OV7610_REG_GAIN          0x00	/* gain setting (5:0) */
#define OV7610_REG_BLUE          0x01	/* blue channel balance */
#define OV7610_REG_RED           0x02	/* red channel balance */
#define OV7610_REG_SAT           0x03	/* saturation */
#define OV8610_REG_HUE           0x04	/* 04 reserved */
#define OV7610_REG_CNT           0x05	/* Y contrast */
#define OV7610_REG_BRT           0x06	/* Y brightness */
					/* 08-0b reserved */
#define OV7610_REG_BLUE_BIAS     0x0C	/* blue channel bias (5:0) */
#define OV7610_REG_RED_BIAS      0x0D	/* read channel bias (5:0) */
#define OV7610_REG_GAMMA_COEFF   0x0E	/* gamma settings */
#define OV7610_REG_WB_RANGE      0x0F	/* AEC/ALC/S-AWB settings */
#define OV7610_REG_EXP           0x10	/* manual exposure setting */
#define OV7610_REG_CLOCK         0x11	/* polarity/clock prescaler */
#define OV7610_REG_COM_A         0x12	/* misc common regs */
#define OV7610_REG_COM_B         0x13	/* misc common regs */
#define OV7610_REG_COM_C         0x14	/* misc common regs */
#define OV7610_REG_COM_D         0x15	/* misc common regs */
#define OV7610_REG_FIELD_DIVIDE  0x16	/* field interval/mode settings */
#define OV7610_REG_HWIN_START    0x17	/* horizontal window start */
#define OV7610_REG_HWIN_END      0x18	/* horizontal window end */
#define OV7610_REG_VWIN_START    0x19	/* vertical window start */
#define OV7610_REG_VWIN_END      0x1A	/* vertical window end */
#define OV7610_REG_PIXEL_SHIFT   0x1B	/* pixel shift */
#define OV7610_REG_ID_HIGH       0x1C	/* manufacturer ID MSB */
#define OV7610_REG_ID_LOW        0x1D	/* manufacturer ID LSB */
					/* 0e-0f reserved */
#define OV7610_REG_COM_E         0x20	/* misc common regs */
#define OV7610_REG_YOFFSET       0x21	/* Y channel offset */
#define OV7610_REG_UOFFSET       0x22	/* U channel offset */
					/* 23 reserved */
#define OV7610_REG_ECW           0x24	/* Exposure white level for AEC */
#define OV7610_REG_ECB           0x25	/* Exposure black level for AEC */
#define OV7610_REG_COM_F         0x26	/* misc settings */
#define OV7610_REG_COM_G         0x27	/* misc settings */
#define OV7610_REG_COM_H         0x28	/* misc settings */
#define OV7610_REG_COM_I         0x29	/* misc settings */
#define OV7610_REG_FRAMERATE_H   0x2A	/* frame rate MSB + misc */
#define OV7610_REG_FRAMERATE_L   0x2B	/* frame rate LSB */
#define OV7610_REG_ALC           0x2C	/* Auto Level Control settings */
#define OV7610_REG_COM_J         0x2D	/* misc settings */
#define OV7610_REG_VOFFSET       0x2E	/* V channel offset adjustment */
#define OV7610_REG_ARRAY_BIAS	 0x2F	/* Array bias -- don't change */
					/* 30-32 reserved */
#define OV7610_REG_YGAMMA        0x33	/* misc gamma settings (7:6) */
#define OV7610_REG_BIAS_ADJUST   0x34	/* misc bias settings */
#define OV7610_REG_COM_L         0x35	/* misc settings */
					/* 36-37 reserved */
#define OV7610_REG_COM_K         0x38	/* misc registers */

/* --------------------------------- */
/*           I2C ADDRESSES           */
/* --------------------------------- */

#define OV7xx0_SID   0x42
#define OV6xx0_SID   0xC0
#define OV8xx0_SID   0xA0
#define OV_HIRES_SID 0x60
#define KS0127_SID   0xD8
#define SAA7111A_SID 0x48

/* --------------------------------- */
/*       MISCELLANEOUS DEFINES       */
/* --------------------------------- */

#define FRAMES_PER_DESC		10	/* FIXME - What should this be? */
#define MAX_FRAME_SIZE_PER_DESC	993	/* For statically allocated stuff */
#define OV511_ENDPOINT_ADDRESS	1	/* Isoc endpoint number */
#define OV511_NUMSBUF		2

#define OV511_NUMFRAMES	2
#if OV511_NUMFRAMES > VIDEO_MAX_FRAME
	#error "OV511_NUMFRAMES is too high"
#endif

/* Control transfers use up to 4 bytes */
#define OV511_CBUF_SIZE		4

/* Size of usb_make_path() buffer */
#define OV511_USB_PATH_LEN	64

/* Bridge types */
enum {
	BRG_UNKNOWN,
	BRG_OV511,
	BRG_OV511PLUS,
	BRG_OV518,
	BRG_OV518PLUS,
	BRG_OV519,
};

/* Bridge classes */
enum {
	BCL_UNKNOWN,
	BCL_OV511,
	BCL_OV518,
	BCL_OV519,
};

/* Sensor types */
enum {
	SEN_UNKNOWN,
	SEN_OV76BE,
	SEN_OV7610,
	SEN_OV7620,
	SEN_OV7620AE,
	SEN_OV7630,
	SEN_OV7640,
	SEN_OV7670,
	SEN_OV6620,
	SEN_OV6630,
	SEN_OV6630AE,
	SEN_OV6630AF,
	SEN_OV8600,
	SEN_OV8610,
	SEN_KS0127,
	SEN_KS0127B,
	SEN_SAA7111A,
};

enum {
	STATE_SCANNING,		/* Scanning for start */
	STATE_HEADER,		/* Parsing header */
	STATE_LINES,		/* Parsing lines */
};

/* Buffer states */
enum {
	BUF_NOT_ALLOCATED,
	BUF_ALLOCATED,
};

/* --------- Definition of ioctl interface --------- */

#define OV511_INTERFACE_VER 101

/* LED options */
enum {
	LED_OFF,
	LED_ON,
	LED_AUTO,
	LED_AUTO_REVERSE,
};

/* Raw frame formats */
enum {
	RAWFMT_INVALID,
	RAWFMT_YUV400,
	RAWFMT_YUV420,
	RAWFMT_YUV422,
	RAWFMT_GBR422,
};

/* Unsigned short option numbers */
enum {
	OV511_USOPT_INVALID,
	OV511_USOPT_BRIGHT,
	OV511_USOPT_SAT,
	OV511_USOPT_HUE,
	OV511_USOPT_CONTRAST,
};

/* Unsigned int option numbers */
enum {
	OV511_UIOPT_INVALID,
	OV511_UIOPT_POWER_FREQ,
	OV511_UIOPT_BFILTER,
	OV511_UIOPT_LED,
	OV511_UIOPT_DEBUG,
	OV511_UIOPT_COMPRESS,
	OV511_UIOPT_LED2,
};

struct ov511_ushort_opt {
	int optnum;		/* Specific option number */
	unsigned short val;
};

struct ov511_uint_opt {
	int optnum;		/* Specific option number */
	unsigned int val;
};

struct ov511_i2c_struct {
	unsigned char slave; /* Write slave ID (read ID - 1) */
	unsigned char reg;   /* Index of register */
	unsigned char value; /* User sets this w/ write, driver does w/ read */
	unsigned char mask;  /* Bits to be changed. Not used with read ops */
};

/* ioctls */
#define OV511IOC_GINTVER  _IOR('v', BASE_VIDIOCPRIVATE + 0, int)
#define OV511IOC_GUSHORT _IOWR('v', BASE_VIDIOCPRIVATE + 1, \
			       struct ov511_ushort_opt)
#define OV511IOC_SUSHORT  _IOW('v', BASE_VIDIOCPRIVATE + 2, \
			       struct ov511_ushort_opt)
#define OV511IOC_GUINT   _IOWR('v', BASE_VIDIOCPRIVATE + 3, \
			       struct ov511_uint_opt)
#define OV511IOC_SUINT    _IOW('v', BASE_VIDIOCPRIVATE + 4, \
			       struct ov511_uint_opt)
#define OV511IOC_WI2C     _IOW('v', BASE_VIDIOCPRIVATE + 5, \
			       struct ov511_i2c_struct)
#define OV511IOC_RI2C    _IOWR('v', BASE_VIDIOCPRIVATE + 6, \
			       struct ov511_i2c_struct)
/* ------------- End IOCTL interface -------------- */

struct usb_ov511;		/* Forward declaration */

struct ov511_sbuf {
	struct usb_ov511 *ov;
	unsigned char *data;
	struct urb *urb;
	spinlock_t lock;
	int n;
};

enum {
	FRAME_UNUSED,		/* Unused (no MCAPTURE) */
	FRAME_READY,		/* Ready to start grabbing */
	FRAME_GRABBING,		/* In the process of being grabbed into */
	FRAME_DONE,		/* Finished grabbing, but not been synced yet */
	FRAME_ERROR,		/* Something bad happened while processing */
};

struct ov511_regvals {
	enum {
		OV511_DONE_BUS,
		OV511_REG_BUS,
		OV511_I2C_BUS,
	} bus;
	unsigned char reg;
	unsigned char val;
};

struct ov511_frame {
	int framenum;		/* Index of this frame */
	unsigned char *data;	/* Frame buffer */
	unsigned char *tempdata; /* Temp buffer for multi-stage conversions */
	unsigned char *rawdata;	/* Raw camera data buffer */
	unsigned char *compbuf;	/* Temp buffer for decompressor */

	int depth;		/* Bytes per pixel */
	int width;		/* Width application is expecting */
	int height;		/* Height application is expecting */

	int rawwidth;		/* Actual width of frame sent from camera */
	int rawheight;		/* Actual height of frame sent from camera */

	int sub_flag;		/* Sub-capture mode for this frame? */
	unsigned int format;	/* Format for this frame */
	int compressed;		/* Is frame compressed? */

	volatile int grabstate;	/* State of grabbing */
	int scanstate;		/* State of scanning */

	int bytes_recvd;	/* Number of image bytes received from camera */

	long bytes_read;	/* Amount that has been read() */

	wait_queue_head_t wq;	/* Processes waiting */

	int snapshot;		/* True if frame was a snapshot */
};

/* Compression module operations */
struct ov51x_decomp_ops {
	int (*decomp_400)(unsigned char *, unsigned char *, unsigned char *,
			  int, int, int);
	int (*decomp_420)(unsigned char *, unsigned char *, unsigned char *,
			  int, int, int);
	int (*decomp_422)(unsigned char *, unsigned char *, unsigned char *,
			  int, int, int);
	struct module *owner;
};

extern struct ov51x_decomp_ops ov511_decomp_ops;
extern struct ov51x_decomp_ops ov518_decomp_ops;
extern struct ov51x_decomp_ops ov519_decomp_ops;

struct usb_ov511 {
	struct video_device *vdev;
	struct usb_device *dev;

	int customid;
	char *desc;
	int imp;		/* Custom device implementation */
	unsigned char iface;
	char usb_path[OV511_USB_PATH_LEN];

	/* Determined by sensor type */
	int maxwidth;
	int maxheight;
	int minwidth;
	int minheight;

	int brightness;
	int colour;
	int contrast;
	int hue;
	int whiteness;
	int exposure;
	int auto_brt;		/* Auto brightness enabled flag */
	int auto_gain;		/* Auto gain control enabled flag */
	int auto_exp;		/* Auto exposure enabled flag */
	int backlight;		/* Backlight exposure algorithm flag */
	int mirror;		/* Image is reversed horizontally */

	int led_policy;		/* LED: off|on|auto; OV511+ and later only */
	int led2_policy;	/* LED 2: off|on|auto; EyeToy only */

	struct semaphore lock;	/* Serializes user-accessible operations */
	int user;		/* user count for exclusive use */

	int streaming;		/* Are we streaming Isochronous? */
	int grabbing;		/* Are we grabbing? */

	int compress;		/* Should the next frame be compressed? */
	int compress_inited;	/* Are compression params uploaded? */

	int lightfreq;		/* Power (lighting) frequency */
	int bandfilt;		/* Banding filter enabled flag */

	unsigned char *fbuf;	/* Videodev buffer area */
	unsigned char *tempfbuf; /* Temporary (intermediate) buffer area */
	unsigned char *rawfbuf;	/* Raw camera data buffer area */

	int sub_flag;		/* Pix Array subcapture on flag */
	int subx;		/* Pix Array subcapture x offset */
	int suby;		/* Pix Array subcapture y offset */
	int subw;		/* Pix Array subcapture width */
	int subh;		/* Pix Array subcapture height */

	int framerate;		/* current Framerate (OV519 only) */
	int clockdiv;		/* clockdiv override for OV519 only */
	int curframe;		/* Frame currently being written to */
	struct ov511_frame frame[OV511_NUMFRAMES];

	struct ov511_sbuf sbuf[OV511_NUMSBUF];

	wait_queue_head_t wq;	/* Processes waiting */

	int snap_enabled;	/* Snapshot mode enabled */

	int bridge;		/* Type of bridge (BRG_*) */
	int bclass;		/* Class of bridge (BCL_*) */
	int sensor;		/* Type of image sensor chip (SEN_*) */

	int packet_size;	/* Frame size per isoc desc */
	int packet_numbering;	/* Is ISO frame numbering enabled? */

	struct semaphore param_lock;	/* params lock for this camera */

	/* /proc entries, relative to /proc/video/ov511/ */
	struct proc_dir_entry *proc_devdir;   /* Per-device proc directory */
	struct proc_dir_entry *proc_info;     /* <minor#>/info entry */
	struct proc_dir_entry *proc_button;   /* <minor#>/button entry */
	struct proc_dir_entry *proc_control;  /* <minor#>/control entry */

	/* Framebuffer/sbuf management */
	int buf_state;
	struct semaphore buf_lock;

	struct ov51x_decomp_ops *decomp_ops;

	/* Stop streaming while changing picture settings */
	int stop_during_set;

	int stopped;		/* Streaming is temporarily paused */

	/* Video decoder stuff */
	int input;		/* Composite, S-VIDEO, etc... */
	int num_inputs;		/* Number of inputs */
	int norm; 		/* NTSC / PAL / SECAM */
	int has_decoder;	/* Device has a video decoder */
	int pal;		/* Device is designed for PAL resolution */

	/* I2C interface */
	struct semaphore i2c_lock;	  /* Protect I2C controller regs */
	unsigned char primary_i2c_slave;  /* I2C write id of sensor */

	/* Control transaction stuff */
	unsigned char *cbuf;		/* Buffer for payload */
	struct semaphore cbuf_lock;
};

struct ovsensor_window {
	int x;
	int y;
	int width;
	int height;
	int format;
	int quarter;		/* Scale width and height down 2x */
	int clockdiv;		/* Clock divisor setting */
};

/* Used to represent a list of values and their respective symbolic names */
struct symbolic_list {
	int num;
	char *name;
};

#define NOT_DEFINED_STR "Unknown"

/* Returns the name of the matching element in the symbolic_list array. The
 * end of the list must be marked with an element that has a NULL name.
 */
static inline char * 
symbolic(struct symbolic_list list[], int num)
{
	int i;

	for (i = 0; list[i].name != NULL; i++)
			if (list[i].num == num)
				return (list[i].name);

	return (NOT_DEFINED_STR);
}


/* Compression stuff */

#define OV511_QUANTABLESIZE	64
#define OV518_QUANTABLESIZE	32

#define OV511_YQUANTABLE { \
	0, 1, 1, 2, 2, 3, 3, 4, \
	1, 1, 1, 2, 2, 3, 4, 4, \
	1, 1, 2, 2, 3, 4, 4, 4, \
	2, 2, 2, 3, 4, 4, 4, 4, \
	2, 2, 3, 4, 4, 5, 5, 5, \
	3, 3, 4, 4, 5, 5, 5, 5, \
	3, 4, 4, 4, 5, 5, 5, 5, \
	4, 4, 4, 4, 5, 5, 5, 5  \
}

#define OV511_UVQUANTABLE { \
	0, 2, 2, 3, 4, 4, 4, 4, \
	2, 2, 2, 4, 4, 4, 4, 4, \
	2, 2, 3, 4, 4, 4, 4, 4, \
	3, 4, 4, 4, 4, 4, 4, 4, \
	4, 4, 4, 4, 4, 4, 4, 4, \
	4, 4, 4, 4, 4, 4, 4, 4, \
	4, 4, 4, 4, 4, 4, 4, 4, \
	4, 4, 4, 4, 4, 4, 4, 4  \
}

#define OV518_YQUANTABLE { \
	5, 4, 5, 6, 6, 7, 7, 7, \
	5, 5, 5, 5, 6, 7, 7, 7, \
	6, 6, 6, 6, 7, 7, 7, 8, \
	7, 7, 6, 7, 7, 7, 8, 8  \
}

#define OV518_UVQUANTABLE { \
	6, 6, 6, 7, 7, 7, 7, 7, \
	6, 6, 6, 7, 7, 7, 7, 7, \
	6, 6, 6, 7, 7, 7, 7, 8, \
	7, 7, 7, 7, 7, 7, 8, 8  \
}

#endif
