DUO Driver
----------
There are two flavors of DUO driver:
  -duo1024.ko - using 1024 bytes transfers (better performance)
  -duo512.ko - using 512 bytes transfers (better compatibility)
Always try to use duo1024.ko and see if it works on your machine first.

Loading the driver
------------------
To load the driver in the teminal type:
  sudo insmod duo1024.ko
or
  sudo insmod duo512.ko

Unloading the driver
--------------------
To unload the driver in the teminal type:
  sudo rmmod -f duo

Installing the driver
---------------------
To install the driver in the teminal type:
  sudo cp duo1024.ko /lib/modules/$(uname -r)/kernel/drivers/duo.ko
  sudo echo 'duo' >> /etc/modules
  sudo depmod
or
  sudo cp duo512.ko /lib/modules/$(uname -r)/kernel/drivers/duo.ko
  sudo echo 'duo' >> /etc/modules
  sudo depmod

