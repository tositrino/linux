Ubuntu 14.04.02 x64 (Kernel 3.16.0-30-generic)

Pre-requisites:

1) Install the following pre-requisites:
	>sudo apt-get install qt5-default libgoogle-glog-dev libblas-dev liblapack-dev libsuitesparse-dev

2) You must install and load the DUO kernel module before using the DUO camera with this command:
   Run the followinf command to display your kernel version (i.e. 3.16.0-43-generic):
	>uname -r
	>cd DUODriver/<your-kernel-version>
	>sudo ./InstallDriver
	>sudo ./LoadDriver

3) Plug in DUO device and verify that the node 'duo0' appears in /dev directory.

4) Use DUO with the DUODashboard and DUOCalibration applications.

Development:

0) Install dev tools:
	>sudo apt-get install build-essential gdb cmake

1) Install OpenCV:
	>sudo apt-get install libopencv-dev

2) Install Qt5:
	>sudo apt-get install qt5-default qtcreator

3) Build the DUOSDK code samples
